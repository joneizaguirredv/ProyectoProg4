#ifndef TRABAJADOR_H_
#define TRABAJADOR_H_

typedef struct
{
	char *NombreTrabajador;
	char *ApellidoTrabajador;
	char *correoTrabajador;
	char *contrasenaTrabajador;
	int numTrabajador;
	int NSS;

}Trabajador;

void mostrarTrbajador(Trabajador t);

#endif