#ifndef MENU_H_
#define MENU_H_
#include "usuario.h"
#include "hotel.h"

char menuInicial();
char menuTrabajador();
char menuCliente();
int menuHotel();
Usuario datosUsuario();

#endif