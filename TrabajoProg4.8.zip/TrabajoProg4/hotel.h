#ifndef HOTEL_H_
#define HOTEL_H_


typedef struct
{
	char *Compania;
	char *Nombre;
	char *Municipio;
	char *Provincia;
	int numEstrellas;
	int valoracionMedia;
}Hotel;

#endif