#include "usuario.h"
#include <stdio.h>

void mostrarUsuario(Usuario p){
	printf("Nombre: %s", p.NombreUsuario);
}