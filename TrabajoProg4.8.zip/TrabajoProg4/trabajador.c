#include "trabajador.h"
#include <stdio.h>

void mostrarTrbajador(Trabajador t){
	printf("Nombre: %s", t.NombreTrabajador);
}